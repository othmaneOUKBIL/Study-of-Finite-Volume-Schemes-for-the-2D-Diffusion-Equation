rm -fr manapy/*/__pyc*
rm -fr manapy/*/.lock_*
rm -fr manapy/*/*.cpython*
