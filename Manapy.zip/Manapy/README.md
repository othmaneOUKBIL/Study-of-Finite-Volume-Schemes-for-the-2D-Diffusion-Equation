[![Build Status](https://travis-ci.org/imadki/manapy.svg?branch=manapy_hpc)](https://travis-ci.org/imadki/manapy)


# manapy
Coming soon

# install

run 

```python
pip3 install -r requirements.txt
```

```python
python3 -m pip install --user -e .
```

pyccelize functions

```python
./run_pyccel.sh
```